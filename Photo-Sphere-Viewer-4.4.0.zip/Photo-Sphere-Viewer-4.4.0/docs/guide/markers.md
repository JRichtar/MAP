# Markers

Markers are now part a [plugin](../plugins/plugin-markers.md).
