# Intro animation

This a simple intro animation using the `Animation` helper.

<iframe style="width: 100%; height: 600px;" src="//jsfiddle.net/mistic100/wsL1x5k0/embedded/result,js/dark" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
