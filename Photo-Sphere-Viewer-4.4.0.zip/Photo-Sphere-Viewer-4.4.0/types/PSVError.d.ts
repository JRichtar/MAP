/**
 * @summary Custom error used in the lib
 */
export class PSVError extends Error {
  name: 'PSVError';
}
