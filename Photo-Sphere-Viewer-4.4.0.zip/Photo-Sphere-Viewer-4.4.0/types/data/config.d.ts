import { ViewerOptions } from '../Viewer';

/**
 * @summary Default options
 */
export const DEFAULTS: ViewerOptions;
