import { AbstractAdapter } from '../..';

/**
 * @summary Adapter for equirectangular panoramas
 */
export class EquirectangularAdapter extends AbstractAdapter<string> {

}
