export default class ViewerCompat {

  constructor() {
    throw new Error('PhotoSphereViewer#ViewerCompat has been removed, please migrate to v4 Viewer.');
  }

}
